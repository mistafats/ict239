# Basic User Authentication/Login for Flask using MongoEngine and WTForms

## Introduction

A full description of this project is available as a Medium article [here](https://medium.com/@dmitryrastorguev/basic-user-authentication-login-for-flask-using-mongoengine-and-wtforms-922e64ef87fe).
